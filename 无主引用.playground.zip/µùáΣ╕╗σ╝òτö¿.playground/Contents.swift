//无主引用 unowned（ARC机制不受无主引用约束）
import UIKit

class TestA
{
    var name:String
    var ref:TestB? = nil //设置ref的类型（TestB）和值（nil）
    
    init(name:String)
    {
        self.name = name
    }
    
    deinit //deinit函数在销毁的时候运行
    {
        print("test boom - " + self.name)
    }
}

class TestB
{
    var name:String
    
    unowned var ref:TestA //TestB.ref（无主类型）的类型是TestA 无主引用必须要有值
    init(name: String,ref:TestA) {
        self.ref = ref
        self.name = name
    }
    
    deinit //deinit函数在销毁的时候运行
    {
        print("testB boom - " + self.name)
    }
}

var testA:TestA? = TestA(name: "A") //创建变量testA，指向类TestA

testA!.ref = TestB(name: "B", ref: testA!) //更改testA中的变量ref的值为TestB
testA!.ref = nil //更改testA.ref的值为空（剩下指向testB的引用被销毁）（TestB类被销毁，执行第31行的代码）（TestB里的ref变量也被销毁）


testA = nil //更改testA的值为空 TestA被销毁 随后TestB被销毁

//最后输出"testB boom - A" "testA boom - B"
















