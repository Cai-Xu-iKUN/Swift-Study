import UIKit

class TestA
{
    var name:String
    
    lazy var data:() -> Void = {() -> Void in
        print(self.name) //闭包当中的self相当于一个引用，ARC机制受这个引用约束
    }
    
//    lazy var data:() -> Void = {[unowned self]// 这里是将self变成无主引用，即使运行后TestA也会被销毁 () -> Void in
//        print(self.name) //闭包当中的self相当于一个引用，ARC机制受这个引用约束
//    }
//    
    
    init(name:String)
    {
        self.name = name
    }
    
    deinit
    {
        print("Test boom - " + self.name)
    }
}

var t:TestA? = TestA(name: "hello")

t!.data()

t = nil




















