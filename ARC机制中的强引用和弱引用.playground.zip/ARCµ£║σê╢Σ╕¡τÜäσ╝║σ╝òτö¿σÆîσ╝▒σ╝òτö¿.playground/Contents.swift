//ARC机制中的强引用和弱引用
import UIKit

class TestA
{
    var name:String
    var ref:TestB? = nil //设置ref的类型（TestB）和值（nil）
    
    init(name:String)
    {
        self.name = name
    }
    
    deinit //deinit函数在销毁的时候运行
    {
        print("test boom - " + self.name)
    }
}

class TestB
{
    var name:String
    weak var ref:TestA? = nil  //设置ref（弱引用）的类型（TestA）和值（nil）  注意：ARC机制不受弱引用影响，当一个类没有任何一个强引用时，该类就会被销毁
    var ref2:TestA? = nil //设置ref2的类型（TestA）和值（nil）
    init(name: String) {
        self.name = name
    }
    
    deinit //deinit函数在销毁的时候运行
    {
        print("testB boom - " + self.name)
    }
}

var testA:TestA? = TestA(name: "A") //创建变量testA，指向类TestA


var testB:TestB? = TestB(name: "B") //创建变量testB，指向类TestB

testB!.ref = testA //更改testB中的变量ref的值，指向类TestA 注意，该变量是弱引用
testA!.ref = testB //更改testA中的变量ref的值，指向类TestB
testB!.ref2 = testA //更改testB中的变量ref的值，指向类TestA

testB!.ref = nil //更改testB中的变量ref的值为空（指向testA的一个引用被销毁）注意，该变量是弱引用
testA!.ref = nil //更改testA中的变量ref的值为空（指向testB的一个引用被销毁）

testB = nil //更改testB的值为空（剩下指向testB的引用被销毁）（TestB类被销毁，执行第31行的代码）
testA = nil //更改testA的值为空
//注意，TestA类并未销毁，因为第44行的testB.ref变量是弱引用，还有一个testB.ref2强引用指向TestA
//最后输出"testB boom - B"















